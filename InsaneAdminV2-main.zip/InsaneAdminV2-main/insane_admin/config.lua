Config = {}
Config.Locale = 'en'

-- Rank pour reports notification

Config.adminRanks = {
				'owner',
				'dev',
				'superadmin',
				'admin',
				'mod',
}

-- Logs Give Money

discord_webhook = {
	url = "https://discord.com/api/webhooks/802623021110132756/5q0ElqXCR3awRsOWe_MaIE7RvqyCVKWAnwuRtHY66qWFalFc5gK6F6JkylgxPxPqTFwG"
}

-- Logs HRP - Activation NOM / blips / et tout ce qui n'est pas à faire en RP

discord_webhookhrp = {
	url = "https://discord.com/api/webhooks/802623021110132756/5q0ElqXCR3awRsOWe_MaIE7RvqyCVKWAnwuRtHY66qWFalFc5gK6F6JkylgxPxPqTFwG"
}
